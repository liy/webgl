function Geometry(){
  this.vertices = [];
  this.normals = [];

  this.id = Geometry.id++;
}

Geometry.id = 0;