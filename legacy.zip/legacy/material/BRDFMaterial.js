function BRDFMaterial(params){
  Material.call(this);

  
}
var p = BRDFMaterial.prototype = Object.create(Material.prototype);